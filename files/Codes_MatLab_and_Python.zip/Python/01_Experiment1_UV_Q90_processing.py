#!/usr/bin/env python3
# Experiment 1 — UV Q90 image processing


from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import random
import re
import sys
from collections import defaultdict
from pathlib import Path

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy.ndimage import binary_dilation, gaussian_filter, label as ndi_label
from scipy.stats import spearmanr
import tifffile

UV_EXPOSURE_S = 4.7
CY5_EXPOSURE_S = 0.1
DOWNSAMPLE = 4
GAUSSIAN_SIGMA_QUARTER = 10.0
PRIMARY_LOCAL_UV_THRESHOLD_LOG2 = 0.50
SUPPLEMENT_LOCAL_RATIO_THRESHOLD_LOG2 = 0.55
LEAF_POSITIVE_AREA_CUTOFF_PCT = 11.0
SATURATION_CUTOFF_FRACTION = 0.01
RANDOM_SEED = 20260806

GENOTYPE_ORDER = ["Col-0", "a3", "sid2", "a3 sid2", "sid2 nrgs"]
CONDITION_ORDER = ["Mock", "Treatment"]
COLORS = {"Mock": "#E66A00", "Treatment": "#1595C5"}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def block_mean_4(image: np.ndarray) -> np.ndarray:
    if image.shape != (3296, 2400):
        raise ValueError(f"Unexpected raw image shape: {image.shape}")
    return image.astype(np.float32).reshape(824, 4, 600, 4).mean(axis=(1, 3))

def clean_label_image(labels: np.ndarray) -> np.ndarray:

    cleaned = np.zeros_like(labels)
    for leaf_id in np.unique(labels):
        if leaf_id == 0:
            continue
        components, n = ndi_label(labels == leaf_id)
        if n == 0:
            continue
        sizes = np.bincount(components.ravel())[1:]
        keep = int(np.argmax(sizes)) + 1
        cleaned[components == keep] = leaf_id
    return cleaned

def masked_gaussian(values: np.ndarray, mask: np.ndarray, sigma: float) -> np.ndarray:
    weighted = gaussian_filter(np.where(mask, values, 0.0).astype(np.float32), sigma=sigma, mode="nearest")
    weights = gaussian_filter(mask.astype(np.float32), sigma=sigma, mode="nearest")
    return weighted / np.maximum(weights, 1e-6)

def trimmed_background(values: np.ndarray) -> tuple[float, float]:
    values = values[np.isfinite(values)]
    if values.size == 0:
        return 0.0, 1.0
    upper = np.quantile(values, 0.80)
    values = values[values <= upper]
    median = float(np.median(values))
    noise = float(1.4826 * np.median(np.abs(values - median)))
    return median, max(noise, 1.0)

def locate_files(raw_root: Path) -> dict[str, Path]:
    index: dict[str, list[Path]] = defaultdict(list)
    for path in raw_root.rglob("*"):
        if path.is_file():
            index[path.name].append(path)
    unique: dict[str, Path] = {}
    for name, paths in index.items():
        if len(paths) == 1:
            unique[name] = paths[0]
    return unique

def map_old_path(old_path: str, file_index: dict[str, Path]) -> Path:
    name = Path(old_path).name
    if name not in file_index:
        raise FileNotFoundError(f"Could not uniquely map {name}")
    return file_index[name]

def saturation_count_blocks(raw: np.ndarray) -> np.ndarray:

    saturated = raw >= np.iinfo(raw.dtype).max
    return saturated.reshape(824, 4, 600, 4).sum(axis=(1, 3)).astype(np.uint8)

def raw_saturation_fraction(saturation_counts_quarter: np.ndarray, quarter_mask: np.ndarray) -> float:
    denominator = int(quarter_mask.sum()) * 16
    return float(saturation_counts_quarter[quarter_mask].sum() / denominator) if denominator else float("nan")

def crop_with_mask(image: np.ndarray, mask: np.ndarray, padding: int = 10) -> tuple[np.ndarray, np.ndarray]:
    ys, xs = np.where(mask)
    y0, y1 = max(0, ys.min() - padding), min(mask.shape[0], ys.max() + padding + 1)
    x0, x1 = max(0, xs.min() - padding), min(mask.shape[1], xs.max() + padding + 1)
    return image[y0:y1, x0:x1], mask[y0:y1, x0:x1]

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--raw-root", type=Path, required=True)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--roi-inventory", type=Path, required=True)
    p.add_argument("--manual-table", type=Path, required=True)
    p.add_argument("--leaf-label-dir", type=Path, required=True)
    p.add_argument("--measurement-label-dir", type=Path, required=True)
    p.add_argument("--output-final", type=Path, required=True)
    p.add_argument("--output-intermediate", type=Path, required=True)
    return p.parse_args()

def main() -> None:
    args = parse_args()
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    out = args.output_final
    inter = args.output_intermediate
    for folder in [out / "tables", out / "plots", out / "representative_leaves", out / "code",
                   inter / "roi_masks", inter / "diagnostics", inter / "sensitivity"]:
        folder.mkdir(parents=True, exist_ok=True)

    manifest = pd.read_csv(args.manifest)
    roi_inventory = pd.read_csv(args.roi_inventory)
    manual = pd.read_csv(args.manual_table)
    file_index = locate_files(args.raw_root)

    acquisition_cache: dict[int, dict[str, object]] = {}
    rows: list[dict[str, object]] = []
    acquisition_rows: list[dict[str, object]] = []

    for _, acquisition in manifest.sort_values("acquisition_id").iterrows():
        acq = int(acquisition.acquisition_id)
        uv_path = map_old_path(str(acquisition.uv_path), file_index)
        cy5_path = map_old_path(str(acquisition.cy5_path), file_index)
        marker_path = map_old_path(str(acquisition.marker_path), file_index)

        raw_uv = tifffile.imread(uv_path)
        raw_cy5 = tifffile.imread(cy5_path)
        uv = block_mean_4(raw_uv)
        cy5 = block_mean_4(raw_cy5)
        uv_saturation_counts = saturation_count_blocks(raw_uv)
        cy5_saturation_counts = saturation_count_blocks(raw_cy5)

        leaf_labels = clean_label_image(tifffile.imread(args.leaf_label_dir / f"{acq:03d}_leaf_labels_quarter.tif"))
        measurement_labels = clean_label_image(tifffile.imread(args.measurement_label_dir / f"{acq:03d}_measurement_labels_quarter.tif"))
        measurement_labels[leaf_labels != measurement_labels] = 0

        tifffile.imwrite(inter / "roi_masks" / f"{acq:03d}_leaf_labels_quarter_clean.tif", leaf_labels)
        tifffile.imwrite(inter / "roi_masks" / f"{acq:03d}_measurement_labels_quarter_clean.tif", measurement_labels)

        all_leaf_mask = leaf_labels > 0
        global_bg_mask = ~binary_dilation(all_leaf_mask, iterations=5)
        global_uv_bg, global_uv_noise = trimmed_background(uv[global_bg_mask])
        global_cy5_bg, global_cy5_noise = trimmed_background(cy5[global_bg_mask])

        acquisition_cache[acq] = {
            "uv": uv, "cy5": cy5,
            "marker_path": marker_path, "uv_path": uv_path, "cy5_path": cy5_path,
            "leaf_labels": leaf_labels, "measurement_labels": measurement_labels,
            "global_uv_bg": global_uv_bg, "global_uv_noise": global_uv_noise,
            "global_cy5_bg": global_cy5_bg, "global_cy5_noise": global_cy5_noise,
        }

        acquisition_rows.append({
            "acquisition_id": acq,
            "experiment": int(acquisition.experiment),
            "repeat": int(acquisition["repeat"]),
            "challenge": acquisition.challenge,
            "genotype": acquisition.genotype,
            "condition_from_filename": acquisition.condition,
            "uv_path_current": str(uv_path),
            "cy5_path_current": str(cy5_path),
            "marker_path_current": str(marker_path),
            "uv_sha256": sha256(uv_path),
            "cy5_sha256": sha256(cy5_path),
            "marker_sha256": sha256(marker_path),
            "uv_exposure_seconds": UV_EXPOSURE_S,
            "cy5_exposure_seconds": CY5_EXPOSURE_S,
            "global_uv_background_raw": global_uv_bg,
            "global_uv_background_noise_raw": global_uv_noise,
            "global_cy5_background_raw": global_cy5_bg,
            "global_cy5_background_noise_raw": global_cy5_noise,
        })

        metadata_rows = roi_inventory[roi_inventory.acquisition_id == acq]
        for _, leaf_meta in metadata_rows.sort_values("leaf_id").iterrows():
            leaf_id = int(leaf_meta.leaf_id)
            full_mask = leaf_labels == leaf_id
            measurement_mask = measurement_labels == leaf_id
            if measurement_mask.sum() < 100:
                continue

            ring = binary_dilation(full_mask, iterations=8) & ~binary_dilation(full_mask, iterations=2) & ~all_leaf_mask
            if ring.sum() < 100:
                ring = binary_dilation(full_mask, iterations=15) & ~binary_dilation(full_mask, iterations=2) & ~all_leaf_mask
            if ring.sum() >= 100:
                uv_bg, uv_noise = trimmed_background(uv[ring])
                cy5_bg, cy5_noise = trimmed_background(cy5[ring])
                uv_noise = max(uv_noise, global_uv_noise)
                cy5_noise = max(cy5_noise, global_cy5_noise)
            else:
                uv_bg, uv_noise = global_uv_bg, global_uv_noise
                cy5_bg, cy5_noise = global_cy5_bg, global_cy5_noise

            uv_rate = np.maximum(uv - uv_bg, 0.0) / UV_EXPOSURE_S
            cy5_rate = np.maximum(cy5 - cy5_bg, 0.0) / CY5_EXPOSURE_S
            uv_epsilon = 3.0 * uv_noise / UV_EXPOSURE_S
            cy5_epsilon = 3.0 * cy5_noise / CY5_EXPOSURE_S
            log_uv = np.log2(uv_rate + uv_epsilon)
            log_cy5 = np.log2(cy5_rate + cy5_epsilon)
            log_ratio = log_uv - log_cy5

            ys, xs = np.where(full_mask)
            y0, y1 = max(0, ys.min() - 20), min(full_mask.shape[0], ys.max() + 21)
            x0, x1 = max(0, xs.min() - 20), min(full_mask.shape[1], xs.max() + 21)
            sub_full = full_mask[y0:y1, x0:x1]
            sub_measurement = measurement_mask[y0:y1, x0:x1]

            local_uv_map = log_uv[y0:y1, x0:x1] - masked_gaussian(log_uv[y0:y1, x0:x1], sub_full, GAUSSIAN_SIGMA_QUARTER)
            local_ratio_map = log_ratio[y0:y1, x0:x1] - masked_gaussian(log_ratio[y0:y1, x0:x1], sub_full, GAUSSIAN_SIGMA_QUARTER)
            local_uv_values = local_uv_map[sub_measurement]
            local_ratio_values = local_ratio_map[sub_measurement]

            uv_sat = raw_saturation_fraction(uv_saturation_counts, measurement_mask)
            cy5_sat = raw_saturation_fraction(cy5_saturation_counts, measurement_mask)
            primary = bool(uv_sat <= SATURATION_CUTOFF_FRACTION and cy5_sat <= SATURATION_CUTOFF_FRACTION)

            row = {
                "dataset": f"exp{int(leaf_meta.experiment)}_r{int(leaf_meta['repeat'])}_{leaf_meta.challenge}",
                "acquisition_id": acq,
                "experiment": int(leaf_meta.experiment),
                "repeat": int(leaf_meta["repeat"]),
                "challenge": leaf_meta.challenge,
                "genotype": leaf_meta.genotype,
                "condition": leaf_meta.condition,
                "leaf_id": leaf_id,
                "analysis_roi": "anatomical_right_half" if int(leaf_meta.experiment) == 1 else "whole_leaf",
                "measurement_pixels_quarter": int(measurement_mask.sum()),
                "local_uv_contrast_q50_log2": float(np.quantile(local_uv_values, 0.50)),
                "local_uv_contrast_q90_log2": float(np.quantile(local_uv_values, 0.90)),
                "local_uv_contrast_q95_log2": float(np.quantile(local_uv_values, 0.95)),
                "high_uv_area_pct_gt_0p50_log2": float(100.0 * np.mean(local_uv_values > PRIMARY_LOCAL_UV_THRESHOLD_LOG2)),
                "image_positive_high_area_ge_11pct": bool(100.0 * np.mean(local_uv_values > PRIMARY_LOCAL_UV_THRESHOLD_LOG2) >= LEAF_POSITIVE_AREA_CUTOFF_PCT),
                "local_ratio_contrast_q90_log2_supplement": float(np.quantile(local_ratio_values, 0.90)),
                "high_ratio_area_pct_gt_0p55_log2_supplement": float(100.0 * np.mean(local_ratio_values > SUPPLEMENT_LOCAL_RATIO_THRESHOLD_LOG2)),
                "uv_rate_median": float(np.median(uv_rate[measurement_mask])),
                "uv_rate_q90": float(np.quantile(uv_rate[measurement_mask], 0.90)),
                "cy5_rate_median": float(np.median(cy5_rate[measurement_mask])),
                "cy5_rate_q90": float(np.quantile(cy5_rate[measurement_mask], 0.90)),
                "uv_local_background_raw": float(uv_bg),
                "uv_local_background_noise_raw": float(uv_noise),
                "cy5_local_background_raw": float(cy5_bg),
                "cy5_local_background_noise_raw": float(cy5_noise),
                "uv_saturated_fraction": uv_sat,
                "cy5_saturated_fraction": cy5_sat,
                "analysis_inclusion_primary": primary,
                "analysis_exclusion_reason": "" if primary else "more_than_1_percent_saturation_in_at_least_one_channel",
                "marker_path": str(marker_path),
                "uv_path": str(uv_path),
                "cy5_path": str(cy5_path),
            }
            for threshold in [0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.80]:
                row[f"high_uv_area_pct_gt_{threshold:.2f}_log2"] = float(100.0 * np.mean(local_uv_values > threshold))
            rows.append(row)

    leaf_all = pd.DataFrame(rows)
    leaf_primary = leaf_all[leaf_all.analysis_inclusion_primary].copy()
    acquisition_table = pd.DataFrame(acquisition_rows)

    leaf_all.to_csv(out / "tables" / "01_leaf_level_all.csv", index=False)
    leaf_primary.to_csv(out / "tables" / "02_leaf_level_primary_qc.csv", index=False)
    acquisition_table.to_csv(out / "tables" / "03_acquisition_manifest_metadata_sha256.csv", index=False)
    roi_inventory.to_csv(out / "tables" / "04_roi_inventory.csv", index=False)
    manual.to_csv(out / "tables" / "05_manual_yes_no_reference_separate_endpoint.csv", index=False)

    group = leaf_primary.groupby(["dataset", "experiment", "repeat", "challenge", "genotype", "condition"]).agg(
        n_qc_leaves=("leaf_id", "size"),
        high_uv_area_median_pct=("high_uv_area_pct_gt_0p50_log2", "median"),
        high_uv_area_q25_pct=("high_uv_area_pct_gt_0p50_log2", lambda x: np.quantile(x, 0.25)),
        high_uv_area_q75_pct=("high_uv_area_pct_gt_0p50_log2", lambda x: np.quantile(x, 0.75)),
        local_uv_q90_median_log2=("local_uv_contrast_q90_log2", "median"),
        local_uv_q90_q25_log2=("local_uv_contrast_q90_log2", lambda x: np.quantile(x, 0.25)),
        local_uv_q90_q75_log2=("local_uv_contrast_q90_log2", lambda x: np.quantile(x, 0.75)),
        image_positive_leaves=("image_positive_high_area_ge_11pct", "sum"),
        image_total_leaves=("image_positive_high_area_ge_11pct", "size"),
        image_percent_positive=("image_positive_high_area_ge_11pct", lambda x: 100.0 * np.mean(x)),
    ).reset_index()
    group.to_csv(out / "tables" / "06_group_summary_primary.csv", index=False)

    validation_parts = []
    for exp in [1, 2]:
        m = manual[manual.manual_experiment_label == exp].copy()
        g = group[(group.experiment == exp) & (group["repeat"] == 1)].copy()
        v = m.merge(g, on=["challenge", "genotype", "condition"], how="inner")
        v["manual_experiment"] = exp
        validation_parts.append(v)
    validation = pd.concat(validation_parts, ignore_index=True)
    validation.to_csv(out / "tables" / "07_manual_vs_image_validation.csv", index=False)

    validation_stats = []
    for metric in ["local_uv_q90_median_log2", "high_uv_area_median_pct", "image_percent_positive"]:
        rho, p = spearmanr(validation.percent_positive, validation[metric])
        matches = 0
        total = 0
        for _, pair in validation.groupby(["manual_experiment", "challenge", "genotype"]):
            if set(pair.condition) == {"Mock", "Treatment"}:
                manual_delta = float(pair.loc[pair.condition == "Mock", "percent_positive"].iloc[0] - pair.loc[pair.condition == "Treatment", "percent_positive"].iloc[0])
                image_delta = float(pair.loc[pair.condition == "Mock", metric].iloc[0] - pair.loc[pair.condition == "Treatment", metric].iloc[0])
                matches += int(np.sign(manual_delta) == np.sign(image_delta))
                total += 1
        validation_stats.append({"metric": metric, "spearman_rho": rho, "p_value": p, "paired_direction_matches": matches, "paired_direction_total": total})
    pd.DataFrame(validation_stats).to_csv(out / "tables" / "08_validation_statistics.csv", index=False)

    saturation = leaf_all[~leaf_all.analysis_inclusion_primary].copy()
    saturation.to_csv(out / "tables" / "09_saturation_exclusions.csv", index=False)

    make_plots(leaf_primary, group, validation, out)
    make_representatives(leaf_primary, manual, manifest, acquisition_cache, out)
    make_sensitivity(leaf_primary, manual, inter)

    config = {
        "analysis_version": "final_corrected_local_uv_v4",
        "primary_channel": "UV (365 nm excitation, Cy3(UV) emission filter)",
        "uv_exposure_seconds": UV_EXPOSURE_S,
        "cy5_exposure_seconds": CY5_EXPOSURE_S,
        "primary_metric": "90th percentile of local UV log2 contrast",
        "primary_area_metric": "percentage of analysis ROI with local UV contrast > 0.50 log2",
        "local_baseline": "mask-normalized Gaussian smooth of log2 exposure-normalized UV signal",
        "gaussian_sigma_quarter_pixels": GAUSSIAN_SIGMA_QUARTER,
        "gaussian_sigma_native_pixels": GAUSSIAN_SIGMA_QUARTER * DOWNSAMPLE,
        "area_threshold_log2": PRIMARY_LOCAL_UV_THRESHOLD_LOG2,
        "area_threshold_fold": float(2 ** PRIMARY_LOCAL_UV_THRESHOLD_LOG2),
        "image_positive_area_cutoff_percent": LEAF_POSITIVE_AREA_CUTOFF_PCT,
        "experiment_1_roi": "anatomical right half only",
        "experiment_2_roi": "whole leaf",
        "saturation_exclusion_fraction": SATURATION_CUTOFF_FRACTION,
        "ratio_status": "supplementary sensitivity only; not used for primary inference",
        "random_seed": RANDOM_SEED,
    }
    (out / "tables" / "10_analysis_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    software = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "opencv": cv2.__version__,
        "matplotlib": matplotlib.__version__,
        "tifffile": tifffile.__version__,
    }
    (out / "code" / "software_versions.json").write_text(json.dumps(software, indent=2), encoding="utf-8")

    report = [
        "FINAL VALIDATION REPORT",
        "=======================",
        f"All segmented leaves: {len(leaf_all)}",
        f"Primary QC leaves: {len(leaf_primary)}",
        f"Saturation exclusions: {len(saturation)}",
        "",
    ]
    for item in validation_stats:
        report.append(f"{item['metric']}: Spearman rho={item['spearman_rho']:.3f}, p={item['p_value']:.3g}, direction matches={item['paired_direction_matches']}/{item['paired_direction_total']}")
    report.extend([
        "",
        "Interpretation: manual yes/no incidence and pixel-area endpoints are distinct and are not expected to have identical percentages.",
        "The corrected image endpoints no longer use the left leaf half as a condition-dependent reference.",
    ])
    (out / "FINAL_VALIDATION_REPORT.txt").write_text("\n".join(report), encoding="utf-8")

def ordered_genotypes(data: pd.DataFrame) -> list[str]:
    present = set(data.genotype)
    return [g for g in GENOTYPE_ORDER if g in present]

def draw_boxplot(data: pd.DataFrame, metric: str, ylabel: str, title: str, output_base: Path, y_min: float | None = None) -> None:
    fig, ax = plt.subplots(figsize=(10.2, 6.2))
    genotypes = ordered_genotypes(data)
    offsets = {"Mock": -0.18, "Treatment": 0.18}
    rng = np.random.default_rng(RANDOM_SEED)
    legend_handles = []
    for gi, genotype in enumerate(genotypes, start=1):
        for condition in CONDITION_ORDER:
            values = data[(data.genotype == genotype) & (data.condition == condition)][metric].dropna().to_numpy()
            if values.size == 0:
                continue
            pos = gi + offsets[condition]
            bp = ax.boxplot(values, positions=[pos], widths=0.28, patch_artist=True, showfliers=False,
                            medianprops={"color": "#222222", "linewidth": 1.5},
                            whiskerprops={"color": COLORS[condition], "linewidth": 1.2},
                            capprops={"color": COLORS[condition], "linewidth": 1.2})
            bp["boxes"][0].set_facecolor(COLORS[condition])
            bp["boxes"][0].set_alpha(0.45)
            bp["boxes"][0].set_edgecolor(COLORS[condition])
            jitter = rng.uniform(-0.055, 0.055, values.size)
            sc = ax.scatter(np.full(values.size, pos) + jitter, values, s=25, color=COLORS[condition], edgecolor="white", linewidth=0.4, zorder=3)
            if gi == 1:
                legend_handles.append(sc)
    ax.set_xticks(range(1, len(genotypes) + 1), genotypes)
    ax.set_xlabel("Genotype", fontweight="bold")
    ax.set_ylabel(ylabel, fontweight="bold")
    ax.set_title(title, fontweight="bold")
    ax.grid(axis="y", alpha=0.25)
    ax.spines[["top", "right"]].set_visible(False)
    if y_min is not None:
        ax.set_ylim(bottom=y_min)
    if legend_handles:
        ax.legend(legend_handles, CONDITION_ORDER, frameon=False, loc="best")
    fig.text(0.5, 0.015, "QC-filtered leaves; descriptive leaf-level distribution. Biological-replicate inference requires verified plant/pot IDs.", ha="center", fontsize=8.5)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    fig.savefig(output_base.with_suffix(".png"), dpi=300)
    fig.savefig(output_base.with_suffix(".pdf"))
    plt.close(fig)

def make_plots(leaf: pd.DataFrame, group: pd.DataFrame, validation: pd.DataFrame, out: Path) -> None:
    for dataset, data in leaf.groupby("dataset", sort=False):
        exp = int(data.experiment.iloc[0]); rep = int(data["repeat"].iloc[0]); challenge = data.challenge.iloc[0]
        title = f"Experiment {exp}, Repeat {rep} - {challenge}"
        draw_boxplot(data, "high_uv_area_pct_gt_0p50_log2", "Locally elevated UV area (%)", title,
                     out / "plots" / f"{dataset}_high_uv_area", y_min=0)
        draw_boxplot(data, "local_uv_contrast_q90_log2", "Local UV contrast, 90th percentile (log2)", title,
                     out / "plots" / f"{dataset}_local_uv_q90")

    rho, p = spearmanr(validation.percent_positive, validation.local_uv_q90_median_log2)
    fig, ax = plt.subplots(figsize=(7, 6))
    for condition in CONDITION_ORDER:
        d = validation[validation.condition == condition]
        ax.scatter(d.percent_positive, d.local_uv_q90_median_log2, s=55, color=COLORS[condition], label=condition, alpha=0.85)
    ax.set_xlabel("Manual cell-death-positive leaves (%)", fontweight="bold")
    ax.set_ylabel("Group median local UV q90 contrast (log2)", fontweight="bold")
    ax.set_title(f"Manual incidence vs. corrected image endpoint\nSpearman rho = {rho:.3f}, p = {p:.2g}", fontweight="bold")
    ax.grid(alpha=0.25); ax.spines[["top", "right"]].set_visible(False); ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(out / "plots" / "manual_vs_local_uv_q90_validation.png", dpi=300); fig.savefig(out / "plots" / "manual_vs_local_uv_q90_validation.pdf"); plt.close(fig)

    rho, p = spearmanr(validation.percent_positive, validation.image_percent_positive)
    fig, ax = plt.subplots(figsize=(7, 6))
    for condition in CONDITION_ORDER:
        d = validation[validation.condition == condition]
        ax.scatter(d.percent_positive, d.image_percent_positive, s=55, color=COLORS[condition], label=condition, alpha=0.85)
    ax.plot([0, 100], [0, 100], "--", color="#555555", linewidth=1)
    ax.set_xlim(0, 102); ax.set_ylim(0, 102)
    ax.set_xlabel("Manual cell-death-positive leaves (%)", fontweight="bold")
    ax.set_ylabel("Image-derived positive leaves (%)", fontweight="bold")
    ax.set_title(f"Exploratory binary image classifier\nSpearman rho = {rho:.3f}, p = {p:.2g}", fontweight="bold")
    ax.grid(alpha=0.25); ax.spines[["top", "right"]].set_visible(False); ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(out / "plots" / "manual_vs_image_positive_validation.png", dpi=300); fig.savefig(out / "plots" / "manual_vs_image_positive_validation.pdf"); plt.close(fig)

def make_representatives(leaf: pd.DataFrame, manual: pd.DataFrame, manifest: pd.DataFrame, cache: dict[int, dict[str, object]], out: Path) -> None:
    for dataset, data in leaf.groupby("dataset", sort=False):
        exp = int(data.experiment.iloc[0]); rep = int(data["repeat"].iloc[0]); challenge = data.challenge.iloc[0]
        genotypes = ordered_genotypes(data)
        selections = []
        for genotype in genotypes:
            for condition in CONDITION_ORDER:
                d = data[(data.genotype == genotype) & (data.condition == condition)]
                if d.empty:
                    continue
                med = d.high_uv_area_pct_gt_0p50_log2.median()
                selected = d.iloc[(d.high_uv_area_pct_gt_0p50_log2 - med).abs().argsort().iloc[0]]
                selections.append(selected)
        selection_df = pd.DataFrame(selections)
        selection_df.to_csv(out / "representative_leaves" / f"{dataset}_representative_selection.csv", index=False)

        for mode in ["marker", "local_uv"]:
            fig, axes = plt.subplots(2, len(genotypes), figsize=(2.5 * len(genotypes), 5.6), squeeze=False)
            for row_idx, condition in enumerate(CONDITION_ORDER):
                for col_idx, genotype in enumerate(genotypes):
                    ax = axes[row_idx, col_idx]
                    sel = selection_df[(selection_df.genotype == genotype) & (selection_df.condition == condition)]
                    if sel.empty:
                        ax.axis("off"); continue
                    sel = sel.iloc[0]; acq = int(sel.acquisition_id); leaf_id = int(sel.leaf_id)
                    item = cache[acq]
                    full = item["leaf_labels"] == leaf_id
                    measure = item["measurement_labels"] == leaf_id
                    if mode == "marker":
                        marker = cv2.imread(str(item["marker_path"]), cv2.IMREAD_COLOR)
                        marker = cv2.cvtColor(marker, cv2.COLOR_BGR2RGB)
                        marker_q = cv2.resize(marker, (600, 824), interpolation=cv2.INTER_AREA)
                        crop, crop_mask = crop_with_mask(marker_q, full)
                        display = crop.copy(); display[~crop_mask] = 0
                        ax.imshow(display)
                    else:
                        uv = item["uv"]; cy5 = item["cy5"]; all_leaf = item["leaf_labels"] > 0
                        ring = binary_dilation(full, iterations=8) & ~binary_dilation(full, iterations=2) & ~all_leaf
                        if ring.sum() >= 100:
                            bg, noise = trimmed_background(uv[ring]); noise = max(noise, float(item["global_uv_noise"]))
                        else:
                            bg, noise = float(item["global_uv_bg"]), float(item["global_uv_noise"])
                        log_uv = np.log2(np.maximum(uv - bg, 0) / UV_EXPOSURE_S + 3 * noise / UV_EXPOSURE_S)
                        ys, xs = np.where(full); y0, y1 = max(0, ys.min()-20), min(824, ys.max()+21); x0, x1 = max(0, xs.min()-20), min(600, xs.max()+21)
                        sub_full = full[y0:y1, x0:x1]
                        local = log_uv[y0:y1, x0:x1] - masked_gaussian(log_uv[y0:y1, x0:x1], sub_full, GAUSSIAN_SIGMA_QUARTER)
                        crop_mask = measure[y0:y1, x0:x1]
                        shown = np.ma.masked_where(~crop_mask, local)
                        ax.imshow(shown, cmap="inferno", vmin=-0.25, vmax=1.5)
                    ax.axis("off")
                    if row_idx == 0:
                        ax.set_title(genotype, fontweight="bold")
                    ax.text(0.5, -0.04, f"High area: {sel.high_uv_area_pct_gt_0p50_log2:.1f}%", transform=ax.transAxes, ha="center", va="top", fontsize=9)
                    if col_idx == 0:
                        ax.text(-0.10, 0.5, condition, transform=ax.transAxes, rotation=90, va="center", ha="right", fontweight="bold")
            fig.suptitle(f"Experiment {exp}, Repeat {rep} - {challenge}: representative leaves", fontweight="bold")
            subtitle = "One QC-approved leaf nearest the group median; same selection in marker and UV panels."
            fig.text(0.5, 0.01, subtitle, ha="center", fontsize=8.5)
            fig.tight_layout(rect=(0, 0.03, 1, 0.95))
            fig.savefig(out / "representative_leaves" / f"{dataset}_representative_{mode}.png", dpi=300)
            fig.savefig(out / "representative_leaves" / f"{dataset}_representative_{mode}.pdf")
            plt.close(fig)

def make_sensitivity(leaf: pd.DataFrame, manual: pd.DataFrame, inter: Path) -> None:
    thresholds = [0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.80]
    records = []
    for threshold in thresholds:
        col = f"high_uv_area_pct_gt_{threshold:.2f}_log2"
        group = leaf.groupby(["experiment", "repeat", "challenge", "genotype", "condition"])[col].median().reset_index(name="image_metric")
        parts = []
        for exp in [1, 2]:
            parts.append(manual[manual.manual_experiment_label == exp].merge(group[(group.experiment == exp) & (group["repeat"] == 1)], on=["challenge", "genotype", "condition"], how="inner").assign(manual_exp=exp))
        val = pd.concat(parts, ignore_index=True)
        rho, p = spearmanr(val.percent_positive, val.image_metric)
        matches = 0; total = 0
        for _, pair in val.groupby(["manual_exp", "challenge", "genotype"]):
            if set(pair.condition) == {"Mock", "Treatment"}:
                dm = pair.loc[pair.condition == "Mock", "percent_positive"].iloc[0] - pair.loc[pair.condition == "Treatment", "percent_positive"].iloc[0]
                di = pair.loc[pair.condition == "Mock", "image_metric"].iloc[0] - pair.loc[pair.condition == "Treatment", "image_metric"].iloc[0]
                matches += int(np.sign(dm) == np.sign(di)); total += 1
        records.append({"threshold_log2": threshold, "threshold_fold": 2 ** threshold, "spearman_rho": rho, "p_value": p, "direction_matches": matches, "direction_total": total})
    sensitivity = pd.DataFrame(records)
    sensitivity.to_csv(inter / "sensitivity" / "threshold_sensitivity_validation.csv", index=False)
    fig, ax1 = plt.subplots(figsize=(8, 5))
    ax1.plot(sensitivity.threshold_log2, sensitivity.spearman_rho, marker="o", label="Spearman rho")
    ax1.set_xlabel("Local UV threshold (log2)", fontweight="bold"); ax1.set_ylabel("Spearman rho", fontweight="bold")
    ax1.set_ylim(0, 1); ax1.grid(alpha=0.25)
    ax2 = ax1.twinx(); ax2.plot(sensitivity.threshold_log2, sensitivity.direction_matches, marker="s", linestyle="--", label="Direction matches")
    ax2.set_ylabel("Paired direction matches (of 18)", fontweight="bold"); ax2.set_ylim(0, 18.5)
    ax1.axvline(PRIMARY_LOCAL_UV_THRESHOLD_LOG2, color="#555555", linestyle=":", linewidth=1)
    fig.tight_layout(); fig.savefig(inter / "sensitivity" / "threshold_sensitivity_validation.png", dpi=300); fig.savefig(inter / "sensitivity" / "threshold_sensitivity_validation.pdf"); plt.close(fig)

if __name__ == "__main__":
    main()
