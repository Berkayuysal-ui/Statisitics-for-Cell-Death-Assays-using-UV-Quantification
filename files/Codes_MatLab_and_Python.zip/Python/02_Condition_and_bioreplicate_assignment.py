#!/usr/bin/env python3
# Condition and biological-replicate assignment


from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

DUPLICATE_ACQUISITIONS = {24}
ROW_GAP_FULL_RESOLUTION_PIXELS = 180.0
COMBINED_BOUNDARY_MIN_GAP_PIXELS = 120.0

def expected_total(manual: pd.DataFrame, exp: int, rep: int, challenge: str,
                   genotype: str, condition: str) -> int | None:
    q = manual[
        (manual["experiment"] == exp)
        & (manual["repeat"] == rep)
        & (manual["challenge"] == challenge)
        & (manual["genotype"] == genotype)
        & (manual["condition"] == condition)
    ]
    if len(q) != 1:
        return None
    return int(q["manual_total"].iloc[0])

def apply_corrections(leaf: pd.DataFrame, roi: pd.DataFrame,
                      manual: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame,
                                                     pd.DataFrame, pd.DataFrame]:
    leaf = leaf[~leaf["acquisition_id"].isin(DUPLICATE_ACQUISITIONS)].copy()
    roi = roi[~roi["acquisition_id"].isin(DUPLICATE_ACQUISITIONS)].copy()

    assignment_blocks: list[pd.DataFrame] = []
    boundary_log: list[dict] = []

    for acquisition_id, group in roi.groupby("acquisition_id"):
        exp = int(group["experiment"].iloc[0])
        rep = int(group["repeat"].iloc[0])
        challenge = str(group["challenge"].iloc[0])
        genotype = str(group["genotype"].iloc[0])
        layout = str(group["layout"].iloc[0])

        if layout == "combined_vertical":
            assigned = group.sort_values("centroid_y_full_est").copy()
            y = assigned["centroid_y_full_est"].to_numpy(float)
            gaps = np.diff(y)
            mock_target = expected_total(
                manual, exp, rep, challenge, genotype, "Mock"
            )
            candidates = [
                index + 1 for index, gap in enumerate(gaps)
                if gap > COMBINED_BOUNDARY_MIN_GAP_PIXELS
            ]
            if not candidates:
                candidates = list(range(1, len(assigned)))

            def score(split_index: int) -> float:
                target_penalty = (
                    abs(split_index - mock_target) * 1000
                    if mock_target is not None else 0
                )
                return target_penalty - float(gaps[split_index - 1])

            split_index = min(candidates, key=score)
            assigned["condition_corrected"] = (
                ["Mock"] * split_index
                + ["Treatment"] * (len(assigned) - split_index)
            )
            selected_gap = float(gaps[split_index - 1])
        else:
            assigned = group.copy()
            assigned["condition_corrected"] = assigned["condition"]
            mock_target = expected_total(
                manual, exp, rep, challenge, genotype, "Mock"
            )
            split_index = None
            selected_gap = None

        boundary_log.append({
            "acquisition_id": int(acquisition_id),
            "experiment": exp,
            "repeat": rep,
            "challenge": challenge,
            "genotype": genotype,
            "layout": layout,
            "selected_split_index": split_index,
            "selected_gap_pixels": selected_gap,
            "manual_mock_total": mock_target,
            "detected_total_before_qc": len(assigned),
        })

        for condition, condition_group in assigned.groupby("condition_corrected"):
            condition_group = condition_group.copy()
            target = expected_total(
                manual, exp, rep, challenge, genotype, condition
            )
            condition_group["manual_aligned_roi_keep"] = True
            log_area = np.log(
                condition_group["leaf_area_px_full_est"].astype(float).to_numpy()
            )
            median = np.median(log_area)
            mad = np.median(np.abs(log_area - median))
            robust_scale = max(1.4826 * mad, 0.05)
            condition_group["area_outlier_abs_z"] = np.abs(
                (log_area - median) / robust_scale
            )

            if target is not None and len(condition_group) > target:
                number_to_drop = len(condition_group) - target
                drop_index = condition_group.sort_values(
                    ["area_outlier_abs_z", "leaf_area_px_full_est"],
                    ascending=[False, True],
                ).head(number_to_drop).index
                condition_group.loc[drop_index, "manual_aligned_roi_keep"] = False

            assignment_blocks.append(condition_group)

    corrected_roi = pd.concat(assignment_blocks, ignore_index=True)

    mapping = corrected_roi.set_index(["acquisition_id", "leaf_id"])[
        ["condition_corrected", "manual_aligned_roi_keep", "area_outlier_abs_z"]
    ].to_dict("index")

    leaf["condition_corrected"] = [
        mapping[(int(a), int(l))]["condition_corrected"]
        for a, l in zip(leaf["acquisition_id"], leaf["leaf_id"])
    ]
    leaf["manual_aligned_roi_keep"] = [
        bool(mapping[(int(a), int(l))]["manual_aligned_roi_keep"])
        for a, l in zip(leaf["acquisition_id"], leaf["leaf_id"])
    ]
    leaf["area_outlier_abs_z"] = [
        float(mapping[(int(a), int(l))]["area_outlier_abs_z"])
        for a, l in zip(leaf["acquisition_id"], leaf["leaf_id"])
    ]

    replicate_mapping: dict[tuple[int, int], int] = {}
    row_log: list[dict] = []
    kept_roi = corrected_roi[corrected_roi["manual_aligned_roi_keep"]]

    for acquisition_id, group in kept_roi.groupby("acquisition_id"):
        for condition, condition_group in group.groupby("condition_corrected"):
            condition_group = condition_group.sort_values("centroid_y_full_est").copy()
            row_numbers = [1]
            for gap in np.diff(condition_group["centroid_y_full_est"].to_numpy(float)):
                row_numbers.append(
                    row_numbers[-1] + int(gap > ROW_GAP_FULL_RESOLUTION_PIXELS)
                )
            condition_group["biological_replicate_row"] = row_numbers

            for _, row in condition_group.iterrows():
                replicate_mapping[(int(acquisition_id), int(row["leaf_id"]))] = int(
                    row["biological_replicate_row"]
                )

            for row_number, replicate in condition_group.groupby(
                "biological_replicate_row"
            ):
                row_log.append({
                    "acquisition_id": int(acquisition_id),
                    "condition": condition,
                    "biological_replicate_row": int(row_number),
                    "n_leaves": len(replicate),
                    "mean_centroid_y": replicate["centroid_y_full_est"].mean(),
                    "min_centroid_y": replicate["centroid_y_full_est"].min(),
                    "max_centroid_y": replicate["centroid_y_full_est"].max(),
                })

    leaf["biological_replicate_row"] = [
        replicate_mapping.get((int(a), int(l)), np.nan)
        for a, l in zip(leaf["acquisition_id"], leaf["leaf_id"])
    ]
    corrected_leaf = leaf[leaf["manual_aligned_roi_keep"]].copy()
    corrected_leaf["condition_original"] = corrected_leaf["condition"]
    corrected_leaf["condition"] = corrected_leaf["condition_corrected"]
    corrected_leaf["biological_replicate_id"] = (
        "A" + corrected_leaf["acquisition_id"].astype(str).str.zfill(3)
        + "_" + corrected_leaf["condition"].str[0]
        + "_R" + corrected_leaf["biological_replicate_row"].astype("Int64").astype(str)
    )
    corrected_leaf["dataset"] = (
        "exp" + corrected_leaf["experiment"].astype(str)
        + "_r" + corrected_leaf["repeat"].astype(str)
        + "_" + corrected_leaf["challenge"]
    )

    detected = corrected_leaf.groupby(
        ["experiment", "repeat", "challenge", "genotype", "condition"]
    ).size().reset_index(name="image_detected_total")
    reconciliation = manual.merge(
        detected,
        on=["experiment", "repeat", "challenge", "genotype", "condition"],
        how="left",
    )
    reconciliation["image_minus_manual_total"] = (
        reconciliation["image_detected_total"] - reconciliation["manual_total"]
    )

    return (
        corrected_leaf,
        pd.DataFrame(boundary_log),
        pd.DataFrame(row_log),
        reconciliation,
    )

def summarize(corrected_leaf: pd.DataFrame, manual: pd.DataFrame) -> pd.DataFrame:
    corrected_leaf = corrected_leaf.copy()
    corrected_leaf["primary_continuous_uv_q90_log2"] = corrected_leaf[
        "local_uv_contrast_q90_log2"
    ]
    corrected_leaf["secondary_high_uv_area_pct"] = corrected_leaf[
        "high_uv_area_pct_gt_0p50_log2"
    ]

    summary = corrected_leaf.groupby([
        "dataset", "experiment", "repeat", "challenge", "genotype", "condition",
        "acquisition_id", "biological_replicate_id", "biological_replicate_row",
    ]).agg(
        n_leaves=("leaf_id", "size"),
        median_local_uv_q90_log2=("primary_continuous_uv_q90_log2", "median"),
        mean_local_uv_q90_log2=("primary_continuous_uv_q90_log2", "mean"),
        median_high_uv_area_pct=("secondary_high_uv_area_pct", "median"),
        mean_high_uv_area_pct=("secondary_high_uv_area_pct", "mean"),
    ).reset_index()

    return summary.merge(
        manual[[
            "experiment", "repeat", "challenge", "genotype", "condition",
            "manual_positive", "manual_total", "manual_percent_positive",
        ]],
        on=["experiment", "repeat", "challenge", "genotype", "condition"],
        how="left",
    )

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--leaf", required=True, type=Path)
    parser.add_argument("--roi", required=True, type=Path)
    parser.add_argument("--manual", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    leaf = pd.read_csv(args.leaf)
    roi = pd.read_csv(args.roi)
    manual = pd.read_csv(args.manual)

    corrected, boundary, rows, reconciliation = apply_corrections(leaf, roi, manual)
    replicate_summary = summarize(corrected, manual)

    corrected.to_csv(args.output / "02_leaf_level_corrected.csv", index=False)
    replicate_summary.to_csv(
        args.output / "03_biological_replicate_row_summary.csv", index=False
    )
    boundary.to_csv(args.output / "09_condition_boundary_log.csv", index=False)
    rows.to_csv(
        args.output / "10_biological_replicate_row_assignment.csv", index=False
    )
    reconciliation.to_csv(
        args.output / "11_manual_vs_image_leaf_counts.csv", index=False
    )
    (args.output / "v5_parameters.json").write_text(json.dumps({
        "duplicate_acquisitions": sorted(DUPLICATE_ACQUISITIONS),
        "row_gap_full_resolution_pixels": ROW_GAP_FULL_RESOLUTION_PIXELS,
        "combined_boundary_min_gap_pixels": COMBINED_BOUNDARY_MIN_GAP_PIXELS,
    }, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
