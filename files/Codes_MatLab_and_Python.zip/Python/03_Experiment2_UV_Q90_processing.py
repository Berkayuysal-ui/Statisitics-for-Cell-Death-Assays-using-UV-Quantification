#!/usr/bin/env python3
# Experiment 2 — absolute UV Q90 processing


from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tifffile
from scipy.ndimage import (
    binary_dilation, binary_fill_holes, distance_transform_edt,
    gaussian_filter,
)
from scipy.stats import spearmanr
from skimage.feature import peak_local_max
from skimage.filters import threshold_otsu
from skimage.measure import regionprops
from skimage.morphology import closing, disk, remove_small_objects
from skimage.segmentation import watershed

UV_EXPOSURE_S = 4.7
CY5_EXPOSURE_S = 0.1
RANDOM_SEED = 20260806
GENOTYPE_ORDER = ["Col-0", "a3", "sid2", "a3 sid2", "sid2 nrgs"]
COLORS = {"Mock": "#E66A00", "Treatment": "#1595C5"}

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--exp2r2-raw-root", type=Path, required=True)
    p.add_argument("--v5-leaf-table", type=Path, required=True)
    p.add_argument("--manual-table", type=Path, required=True)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--seed-label-dir", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    return p.parse_args()

def block_mean4(raw: np.ndarray) -> np.ndarray:
    if raw.shape != (3296, 2400):
        raise ValueError(f"Unexpected TIFF shape: {raw.shape}")
    return raw.astype(np.float32).reshape(824, 4, 600, 4).mean(axis=(1, 3))

def robust_background(values: np.ndarray) -> tuple[float, float]:
    values = values[np.isfinite(values)]
    upper = np.quantile(values, 0.80)
    values = values[values <= upper]
    median = float(np.median(values))
    noise = float(1.4826 * np.median(np.abs(values - median)))
    return median, max(noise, 1.0)

def masked_gaussian(values: np.ndarray, mask: np.ndarray, sigma: float = 10.0) -> np.ndarray:
    weighted = gaussian_filter(np.where(mask, values, 0).astype(np.float32), sigma=sigma, mode="nearest")
    weights = gaussian_filter(mask.astype(np.float32), sigma=sigma, mode="nearest")
    return weighted / np.maximum(weights, 1e-6)

def index_files(root: Path) -> dict[str, list[Path]]:
    index: dict[str, list[Path]] = {}
    for path in root.rglob("*"):
        if path.is_file():
            index.setdefault(path.name, []).append(path)
    return index

def resolve(index: dict[str, list[Path]], old_path: str) -> Path:
    name = Path(old_path).name
    paths = index.get(name, [])
    if not paths:
        raise FileNotFoundError(name)
    return paths[0]

def manual_total(manual: pd.DataFrame, challenge: str, genotype: str, condition: str) -> int:
    q = manual[
        (manual.experiment == 2) & (manual["repeat"] == 2)
        & (manual.challenge == challenge) & (manual.genotype == genotype)
        & (manual.condition == condition)
    ]
    if len(q) != 1:
        raise ValueError((challenge, genotype, condition))
    return int(q.manual_total.iloc[0])

def foreground_from_raw(uv: np.ndarray, cy5: np.ndarray, seed_labels: np.ndarray) -> np.ndarray:
    seed_mask = seed_labels > 0
    bg_mask = ~binary_dilation(seed_mask, iterations=5)
    uv_bg, uv_noise = robust_background(uv[bg_mask])
    cy_bg, cy_noise = robust_background(cy5[bg_mask])
    uv_snr = np.maximum(uv - uv_bg, 0) / uv_noise
    cy_snr = np.maximum(cy5 - cy_bg, 0) / cy_noise
    combined = np.maximum(np.log1p(uv_snr), np.log1p(cy_snr))
    values = combined.ravel()
    values = values[(values > 0) & (values < np.quantile(values, 0.999))]
    threshold = max(float(threshold_otsu(values)), 0.8)
    fg = combined > threshold
    fg = closing(fg, disk(3))
    fg = binary_fill_holes(fg)
    fg = remove_small_objects(fg, min_size=180)
    fg |= binary_dilation(seed_mask, iterations=2)
    return binary_fill_holes(fg)

def condition_ids(v5: pd.DataFrame, acquisition_id: int) -> dict[str, set[int]]:
    h = v5[v5.acquisition_id == acquisition_id]
    return {
        condition: set(h[h.condition == condition].leaf_id.astype(int))
        for condition in ["Mock", "Treatment"]
    }

def resegment_acquisition(
    acquisition_id: int,
    acquisition: pd.Series,
    raw_index: dict[str, list[Path]],
    seed_label_dir: Path,
    v5: pd.DataFrame,
    manual: pd.DataFrame,
) -> tuple[np.ndarray, float, np.ndarray, np.ndarray, list[dict[str, object]]]:
    raw_uv = tifffile.imread(resolve(raw_index, acquisition.uv_path))
    raw_cy = tifffile.imread(resolve(raw_index, acquisition.cy5_path))
    uv = block_mean4(raw_uv)
    cy = block_mean4(raw_cy)
    seed_labels = tifffile.imread(seed_label_dir / f"{acquisition_id:03d}_leaf_labels_quarter.tif")
    foreground = foreground_from_raw(uv, cy, seed_labels)

    ids_by_condition = condition_ids(v5, acquisition_id)
    props = {p.label: p for p in regionprops(seed_labels)}
    mock_y = [props[i].centroid[0] for i in ids_by_condition["Mock"] if i in props]
    treatment_y = [props[i].centroid[0] for i in ids_by_condition["Treatment"] if i in props]
    boundary = (max(mock_y) + min(treatment_y)) / 2

    result = np.zeros_like(seed_labels, dtype=np.uint16)
    next_leaf_id = int(seed_labels.max()) + 1
    audit: list[dict[str, object]] = []

    for condition, (y0, y1) in {
        "Mock": (0, int(boundary)),
        "Treatment": (int(boundary), seed_labels.shape[0]),
    }.items():
        fg = foreground[y0:y1]
        seeds = seed_labels[y0:y1]
        markers = np.zeros_like(seeds, dtype=np.int32)
        marker_to_leaf: dict[int, int] = {}
        existing_centers: list[tuple[float, float]] = []
        marker_number = 0

        for leaf_id in sorted(ids_by_condition[condition]):
            mask = seeds == leaf_id
            if not mask.any():
                continue
            marker_number += 1
            eroded = cv2.erode(mask.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=1).astype(bool)
            if not eroded.any():
                eroded = mask
            markers[eroded] = marker_number
            marker_to_leaf[marker_number] = leaf_id
            p = regionprops(mask.astype(np.uint8))[0]
            existing_centers.append((p.centroid[0], p.centroid[1]))

        target = manual_total(manual, acquisition.challenge, acquisition.genotype, condition)
        needed = max(0, target - len(existing_centers))
        distance = distance_transform_edt(fg)
        peaks = peak_local_max(distance, min_distance=8, threshold_abs=4, exclude_border=False)
        centers = np.asarray(existing_centers, dtype=float)
        candidates: list[tuple[float, float, int, int]] = []
        for row, col in peaks:
            nearest = np.min(np.sqrt(((centers - [row, col]) ** 2).sum(axis=1))) if centers.size else 999.0
            if nearest >= 20:
                candidates.append((float(distance[row, col]), float(nearest), int(row), int(col)))
        candidates.sort(reverse=True)

        additions = []
        for score, nearest, row, col in candidates[:needed]:
            marker_number += 1
            cv2.circle(markers, (col, row), 3, marker_number, -1)
            marker_to_leaf[marker_number] = next_leaf_id
            additions.append({
                "leaf_id": next_leaf_id,
                "row_quarter": row + y0,
                "col_quarter": col,
                "distance_transform_score": score,
                "distance_to_existing_seed": nearest,
            })
            next_leaf_id += 1

        segmented = watershed(-distance, markers, mask=fg)
        for marker_id, leaf_id in marker_to_leaf.items():
            mask = segmented == marker_id
            if not mask.any():
                continue
            mask = closing(mask, disk(2))
            mask = binary_fill_holes(mask)
            result[y0:y1][mask] = leaf_id

        audit.append({
            "acquisition_id": acquisition_id,
            "challenge": acquisition.challenge,
            "genotype": acquisition.genotype,
            "condition": condition,
            "manual_total": target,
            "seed_count": len(existing_centers),
            "added_seed_count": len(additions),
            "added_seeds_json": json.dumps(additions),
        })

    return result, boundary, raw_uv, raw_cy, audit

def measure_labels(
    labels: np.ndarray,
    boundary: float,
    raw_uv: np.ndarray,
    raw_cy: np.ndarray,
    acquisition: pd.Series,
) -> pd.DataFrame:
    uv = block_mean4(raw_uv)
    cy = block_mean4(raw_cy)
    all_leaf_mask = labels > 0
    global_bg = ~binary_dilation(all_leaf_mask, iterations=5)
    global_uv_bg, global_uv_noise = robust_background(uv[global_bg])

    rows = []
    props = regionprops(labels)
    by_condition: dict[str, list] = {"Mock": [], "Treatment": []}
    for p in props:
        by_condition["Mock" if p.centroid[0] < boundary else "Treatment"].append(p)

    row_assignment: dict[int, tuple[str, int]] = {}
    for condition, plist in by_condition.items():
        row_number = 1
        previous_y = None
        for p in sorted(plist, key=lambda x: x.centroid[0]):
            if previous_y is not None and p.centroid[0] - previous_y > 45:
                row_number += 1
            row_assignment[p.label] = (condition, row_number)
            previous_y = p.centroid[0]

    for p in props:
        leaf_id = p.label
        mask = labels == leaf_id
        condition, row_number = row_assignment[leaf_id]
        ring = binary_dilation(mask, iterations=8) & ~binary_dilation(mask, iterations=2) & ~all_leaf_mask
        if ring.sum() < 100:
            ring = binary_dilation(mask, iterations=15) & ~binary_dilation(mask, iterations=2) & ~all_leaf_mask
        if ring.sum() >= 100:
            uv_bg, uv_noise = robust_background(uv[ring])
            uv_noise = max(uv_noise, global_uv_noise)
        else:
            uv_bg, uv_noise = global_uv_bg, global_uv_noise

        uv_rate = np.maximum(uv - uv_bg, 0) / UV_EXPOSURE_S
        epsilon = 3 * uv_noise / UV_EXPOSURE_S
        log_uv = np.log2(uv_rate + epsilon)
        values = log_uv[mask]

        saturated = (raw_uv >= np.iinfo(raw_uv.dtype).max).reshape(824, 4, 600, 4).sum(axis=(1, 3))
        saturation_fraction = float(saturated[mask].sum() / (mask.sum() * 16))

        rows.append({
            "dataset": f"exp2_r2_{acquisition.challenge}",
            "acquisition_id": int(acquisition.acquisition_id),
            "experiment": 2,
            "repeat": 2,
            "challenge": acquisition.challenge,
            "genotype": acquisition.genotype,
            "condition": condition,
            "leaf_id": leaf_id,
            "biological_replicate_row": row_number,
            "biological_replicate_id": f"A{int(acquisition.acquisition_id):03d}_{condition[0]}_R{row_number}",
            "analysis_roi": "whole_leaf",
            "measurement_pixels_quarter": int(mask.sum()),
            "uv_log_median": float(np.quantile(values, 0.50)),
            "uv_log_q90": float(np.quantile(values, 0.90)),
            "uv_log_q95": float(np.quantile(values, 0.95)),
            "uv_saturated_fraction": saturation_fraction,
            "segmentation_source": "raw_UV_Cy5_union_seeded_watershed_v6",
        })
    return pd.DataFrame(rows)

def plot_dataset(biorep: pd.DataFrame, group: pd.DataFrame, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    for dataset, data in biorep.groupby("dataset"):
        summary = group[group.dataset == dataset]
        genotypes = [g for g in GENOTYPE_ORDER if g in set(data.genotype)]
        fig, ax = plt.subplots(figsize=(9.6, 5.9))
        offsets = {"Mock": -0.18, "Treatment": 0.18}
        positions, values, colors = [], [], []
        for i, genotype in enumerate(genotypes, 1):
            for condition in ["Mock", "Treatment"]:
                vals = data[(data.genotype == genotype) & (data.condition == condition)].median_leaf_uv_q90_log2.dropna().to_numpy()
                if not len(vals):
                    continue
                positions.append(i + offsets[condition])
                values.append(vals)
                colors.append(COLORS[condition])
        bp = ax.boxplot(values, positions=positions, widths=0.28, patch_artist=True, showfliers=False)
        for patch, color in zip(bp["boxes"], colors):
            patch.set_facecolor(color); patch.set_alpha(0.5); patch.set_edgecolor(color)
        rng = np.random.default_rng(RANDOM_SEED)
        for position, vals, color in zip(positions, values, colors):
            ax.scatter(np.full(len(vals), position) + rng.uniform(-0.045, 0.045, len(vals)), vals,
                       s=38, color=color, edgecolor="white", linewidth=0.5, zorder=3)
        for i, genotype in enumerate(genotypes, 1):
            for condition in ["Mock", "Treatment"]:
                q = summary[(summary.genotype == genotype) & (summary.condition == condition)]
                if len(q):
                    ax.scatter(i + offsets[condition], q.median_uv_q90_log2.iloc[0], marker="D", s=55,
                               facecolor="black", edgecolor="white", linewidth=0.7, zorder=4)
        ax.set_xticks(range(1, len(genotypes) + 1), genotypes)
        ax.set_xlabel("Genotype")
        ax.set_ylabel("UV Q90 (log2 background-corrected counts/s)")
        first = data.iloc[0]
        ax.set_title(f"Experiment {int(first.experiment)}, Repeat {int(first['repeat'])} - {first.challenge}", weight="bold")
        ax.grid(axis="y", alpha=0.25)
        ax.spines[["top", "right"]].set_visible(False)
        fig.tight_layout()
        fig.savefig(output / f"{dataset}_uv_q90_bioreplicates.png", dpi=300, bbox_inches="tight")
        fig.savefig(output / f"{dataset}_uv_q90_bioreplicates.pdf", bbox_inches="tight")
        plt.close(fig)

def main() -> None:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    table_dir = args.output / "tables"; table_dir.mkdir(exist_ok=True)
    mask_dir = args.output / "exp2r2_masks"; mask_dir.mkdir(exist_ok=True)

    v5 = pd.read_csv(args.v5_leaf_table)
    manual = pd.read_csv(args.manual_table)
    manifest = pd.read_csv(args.manifest)
    raw_index = index_files(args.exp2r2_raw_root)

    new_parts = []
    audits = []
    for acquisition_id in range(37, 47):
        acquisition = manifest[manifest.acquisition_id == acquisition_id].iloc[0]
        labels, boundary, raw_uv, raw_cy, audit = resegment_acquisition(
            acquisition_id, acquisition, raw_index, args.seed_label_dir, v5, manual
        )
        tifffile.imwrite(mask_dir / f"{acquisition_id:03d}_raw_channel_union_labels.tif", labels.astype(np.uint16))
        new_parts.append(measure_labels(labels, boundary, raw_uv, raw_cy, acquisition))
        audits.extend(audit)

    exp2r2 = pd.concat(new_parts, ignore_index=True)
    non_exp2r2 = v5[~((v5.experiment == 2) & (v5["repeat"] == 2))].copy()
    keep = [
        "dataset", "acquisition_id", "experiment", "repeat", "challenge", "genotype", "condition", "leaf_id",
        "biological_replicate_row", "biological_replicate_id", "analysis_roi", "measurement_pixels_quarter",
        "uv_log_median", "uv_log_q90", "uv_log_q95", "uv_saturated_fraction",
    ]
    non_exp2r2 = non_exp2r2[keep]
    non_exp2r2["segmentation_source"] = "corrected_v5_marker_seed_masks"
    leaf = pd.concat([non_exp2r2, exp2r2], ignore_index=True)

    rep_keys = [
        "dataset", "experiment", "repeat", "challenge", "genotype", "condition",
        "acquisition_id", "biological_replicate_id", "biological_replicate_row",
    ]
    biorep = leaf.groupby(rep_keys).agg(
        n_leaves=("leaf_id", "size"),
        median_leaf_uv_q90_log2=("uv_log_q90", "median"),
        mean_leaf_uv_q90_log2=("uv_log_q90", "mean"),
    ).reset_index()
    group = leaf.groupby(["dataset", "experiment", "repeat", "challenge", "genotype", "condition"]).agg(
        n_image_leaves=("leaf_id", "size"),
        median_uv_q90_log2=("uv_log_q90", "median"),
    ).reset_index().merge(manual, on=["dataset", "experiment", "repeat", "challenge", "genotype", "condition"], how="left")

    leaf.to_csv(table_dir / "02_leaf_level_uv_q90.csv", index=False)
    biorep.to_csv(table_dir / "03_biological_replicate_uv_q90.csv", index=False)
    group.to_csv(table_dir / "04_group_summary_manual_vs_uv_q90.csv", index=False)
    pd.DataFrame(audits).to_csv(table_dir / "exp2r2_resegmentation_audit.csv", index=False)
    plot_dataset(biorep, group, args.output / "plots_uv_q90")

    rho, p = spearmanr(group.manual_percent_positive, group.median_uv_q90_log2)
    print(f"Spearman rho manual vs UV Q90: {rho:.4f} (p={p:.4g})")

if __name__ == "__main__":
    main()
