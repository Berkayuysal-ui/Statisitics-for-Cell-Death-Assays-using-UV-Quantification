%% CellDeath_Recompute_Statistics_MATLAB.m
%% Cell-death statistics


clear; clc;
rng(20260807,'twister');

baseDir = fileparts(mfilename('fullpath'));
if isempty(baseDir); baseDir = pwd; end

img = readtable(fullfile(baseDir,'Final_Image_BioRep.csv'),'TextType','string');
man = readtable(fullfile(baseDir,'Manual_BioRep_Proportions.csv'),'TextType','string');

imgRepeat = analyseRepeatSpecific(img,'image_value');
imgPooled = analysePooled(img,'image_value');

man.experiment = man.experiment_num;
man.repeat = man.repeat_num;
man.image_value = man.positive_fraction;
manRepeat = analyseRepeatSpecific(man,'image_value');
manPooled = analysePooled(man,'image_value');

writetable(imgRepeat,fullfile(baseDir,'Image_Statistics_Repeat_MATLAB.csv'));
writetable(imgPooled,fullfile(baseDir,'Image_Statistics_Pooled_MATLAB.csv'));
writetable(manRepeat,fullfile(baseDir,'Manual_Statistics_Repeat_MATLAB.csv'));
writetable(manPooled,fullfile(baseDir,'Manual_Statistics_Pooled_MATLAB.csv'));

disp('Statistics recomputed successfully.');

%% -------- local functions --------
function OUT = analyseRepeatSpecific(T,valueVar)
    out = {};
    for expNo = unique(T.experiment)'
        for repNo = unique(T.repeat(T.experiment==expNo))'
            D = T(T.experiment==expNo & T.repeat==repNo,:);
            effectors = unique(D.effector,'stable');
            rowBlock = {};
            for e = 1:numel(effectors)
                eff = effectors(e);
                genotypes = unique(D.genotype(D.effector==eff),'stable');
                for g = 1:numel(genotypes)
                    geno = genotypes(g);
                    x = D.(valueVar)(D.effector==eff & D.genotype==geno & D.condition=="Mock");
                    y = D.(valueVar)(D.effector==eff & D.genotype==geno & D.condition=="Treatment");
                    if isempty(x) || isempty(y); continue; end
                    [delta,p,nPerm] = exactPermutation(x,y);
                    rowBlock(end+1,:) = {expNo,repNo,eff,geno,numel(x),numel(y), ...
                        median(x),median(y),mean(x),mean(y),delta,2.^delta,p,nPerm}; %#ok<AGROW>
                end
            end
            if isempty(rowBlock); continue; end
            B = cell2table(rowBlock,'VariableNames', ...
                {'experiment','repeat','effector','genotype','n_mock','n_treatment', ...
                 'median_mock','median_treatment','mean_mock','mean_treatment', ...
                 'delta_mean_treatment_minus_mock','fold_change','p_raw','n_permutations'});
            B.p_holm = holm(B.p_raw);
            OUTblock = B;
            out{end+1} = OUTblock; %#ok<AGROW>
        end
    end
    OUT = vertcat(out{:});
end

function OUT = analysePooled(T,valueVar)
    out = {};
    for expNo = unique(T.experiment)'
        D = T(T.experiment==expNo,:);
        effectors = unique(D.effector,'stable');
        rowBlock = {};
        for e = 1:numel(effectors)
            eff = effectors(e);
            genotypes = unique(D.genotype(D.effector==eff),'stable');
            for g = 1:numel(genotypes)
                geno = genotypes(g);

                repeatVals = unique(D.repeat(D.effector==eff & D.genotype==geno));
                xBlocks = cell(0,1); yBlocks = cell(0,1);
                allX = []; allY = [];
                mockMeans = []; treatMeans = [];

                for r = 1:numel(repeatVals)
                    repNo = repeatVals(r);
                    x = D.(valueVar)(D.repeat==repNo & D.effector==eff & ...
                        D.genotype==geno & D.condition=="Mock");
                    y = D.(valueVar)(D.repeat==repNo & D.effector==eff & ...
                        D.genotype==geno & D.condition=="Treatment");
                    if isempty(x) || isempty(y); continue; end
                    xBlocks{end+1} = x; %#ok<AGROW>
                    yBlocks{end+1} = y; %#ok<AGROW>
                    allX = [allX; x]; %#ok<AGROW>
                    allY = [allY; y]; %#ok<AGROW>
                    mockMeans(end+1) = mean(x); %#ok<AGROW>
                    treatMeans(end+1) = mean(y); %#ok<AGROW>
                end

                if isempty(xBlocks); continue; end
                [delta,p,nPerm,testMethod] = blockedPermutation(xBlocks,yBlocks);
                rowBlock(end+1,:) = {expNo,eff,geno,numel(allX),numel(allY), ...
                    median(allX),median(allY),mean(mockMeans),mean(treatMeans), ...
                    delta,2.^delta,p,nPerm,testMethod}; %#ok<AGROW>
            end
        end

        B = cell2table(rowBlock,'VariableNames', ...
            {'experiment','effector','genotype','n_mock','n_treatment', ...
             'pooled_median_mock','pooled_median_treatment', ...
             'blocked_mean_mock','blocked_mean_treatment', ...
             'delta_blocked_mean_treatment_minus_mock','fold_change', ...
             'p_raw','n_permutations','test'});
        B.p_holm = holm(B.p_raw);
        out{end+1} = B; %#ok<AGROW>
    end
    OUT = vertcat(out{:});
end

function [obs,p,nPerm] = exactPermutation(x,y)
    x = x(:); y = y(:);
    pooled = [x;y];
    nMock = numel(x);
    n = numel(pooled);
    obs = mean(y)-mean(x);

    C = nchoosek(1:n,nMock);
    stats = zeros(size(C,1),1);
    allIdx = (1:n)';
    for i = 1:size(C,1)
        isMock = false(n,1);
        isMock(C(i,:)) = true;
        stats(i) = mean(pooled(~isMock))-mean(pooled(isMock));
    end
    p = mean(abs(stats) >= abs(obs)-1e-12);
    nPerm = numel(stats);
end

function [obs,p,nPerm,method] = blockedPermutation(xBlocks,yBlocks)
    nBlocks = numel(xBlocks);
    obsDiff = zeros(nBlocks,1);
    statSets = cell(nBlocks,1);

    for b = 1:nBlocks
        x = xBlocks{b}(:); y = yBlocks{b}(:);
        obsDiff(b) = mean(y)-mean(x);

        pooled = [x;y];
        nMock = numel(x);
        n = numel(pooled);
        C = nchoosek(1:n,nMock);
        st = zeros(size(C,1),1);
        for i = 1:size(C,1)
            isMock = false(n,1);
            isMock(C(i,:)) = true;
            st(i) = mean(pooled(~isMock))-mean(pooled(isMock));
        end
        statSets{b} = st;
    end

    obs = mean(obsDiff);
    nComb = cellfun(@numel,statSets);
    total = prod(nComb);

    if nBlocks==1
        allStats = statSets{1};
        p = mean(abs(allStats) >= abs(obs)-1e-12);
        nPerm = numel(allStats);
        method = "exact permutation";
        return
    end

    if nBlocks==2 && total <= 1e6
        s1 = statSets{1};
        s2 = statSets{2};
        extreme = 0;
        for i = 1:numel(s1)
            vals = (s1(i)+s2)./2;
            extreme = extreme + sum(abs(vals) >= abs(obs)-1e-12);
        end
        p = extreme/total;
        nPerm = total;
        method = "exact repeat-blocked permutation (equal repeat weight)";
    else
        N = 200000;
        extreme = 0;
        for k = 1:N
            vals = zeros(nBlocks,1);
            for b = 1:nBlocks
                st = statSets{b};
                vals(b) = st(randi(numel(st)));
            end
            stat = mean(vals);
            extreme = extreme + (abs(stat) >= abs(obs)-1e-12);
        end
        p = (extreme+1)/(N+1);
        nPerm = N;
        method = "Monte Carlo repeat-blocked permutation (equal repeat weight)";
    end
end

function adj = holm(p)
    p = p(:);
    m = numel(p);
    [ps,ord] = sort(p);
    a = zeros(m,1);
    running = 0;
    for k = 1:m
        val = (m-k+1)*ps(k);
        running = max(running,val);
        a(k) = min(1,running);
    end
    adj = zeros(m,1);
    adj(ord) = a;
end
