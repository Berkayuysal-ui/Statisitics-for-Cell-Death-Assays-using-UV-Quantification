%% CellDeath_Final_Plots_MATLAB.m
%% Cell-death figures


clear; close all; clc;

baseDir = fileparts(mfilename('fullpath'));
if isempty(baseDir); baseDir = pwd; end
figDir = fullfile(baseDir,'Figures');
if ~exist(figDir,'dir'); mkdir(figDir); end

img = readtable(fullfile(baseDir,'Final_Image_BioRep.csv'),'TextType','string');
imgRepStats = readtable(fullfile(baseDir,'Image_Statistics_Repeat.csv'),'TextType','string');
imgPoolStats = readtable(fullfile(baseDir,'Image_Statistics_Pooled.csv'),'TextType','string');

man = readtable(fullfile(baseDir,'Manual_BioRep_Proportions.csv'),'TextType','string');
manRepStats = readtable(fullfile(baseDir,'Manual_Statistics_Repeat.csv'),'TextType','string');
manPoolStats = readtable(fullfile(baseDir,'Manual_Statistics_Combined.csv'),'TextType','string');

effectors = ["AvrRpt2","AvrRps4"];

for expNo = 1:2
    if expNo == 1
        genotypes = ["Col-0","sid2","a3","a3 sid2"];
        yLab = "Local UV contrast Q90 (log_2)";
    else
        genotypes = ["Col-0","sid2","sid2 nrgs","a3","a3 sid2"];
        yLab = "Absolute UV Q90 (log_2 a.u.)";
    end

    for eff = effectors
        for repNo = 1:2
            d = img(img.experiment==expNo & img.repeat==repNo & img.effector==eff,:);
            s = imgRepStats(imgRepStats.experiment==expNo & imgRepStats.repeat==repNo & imgRepStats.effector==eff,:);
            ttl = sprintf('Experiment %d | Repeat %d | %s',expNo,repNo,eff);
            stem = sprintf('Image_Exp%d_Repeat%d_%s',expNo,repNo,eff);
            makeBoxplotImage(d,s,genotypes,yLab,ttl,figDir,stem,false);
        end

        d = img(img.experiment==expNo & img.effector==eff,:);
        s = imgPoolStats(imgPoolStats.experiment==expNo & imgPoolStats.effector==eff,:);
        ttl = sprintf('Experiment %d | pooled repeats | %s',expNo,eff);
        stem = sprintf('Image_Exp%d_Pooled_%s',expNo,eff);
        makeBoxplotImage(d,s,genotypes,yLab,ttl,figDir,stem,true);

        for repNo = 1:2
            d = man(man.experiment_num==expNo & man.repeat_num==repNo & man.effector==eff,:);
            s = manRepStats(manRepStats.experiment==expNo & manRepStats.repeat==repNo & manRepStats.effector==eff,:);
            ttl = sprintf('Manual cell death | Experiment %d | Repeat %d | %s',expNo,repNo,eff);
            stem = sprintf('Manual_Exp%d_Repeat%d_%s',expNo,repNo,eff);
            makeBoxplotManual(d,s,genotypes,ttl,figDir,stem,false);
        end

        d = man(man.experiment_num==expNo & man.effector==eff,:);
        s = manPoolStats(manPoolStats.experiment==expNo & manPoolStats.effector==eff,:);
        ttl = sprintf('Manual cell death | Experiment %d | pooled repeats | %s',expNo,eff);
        stem = sprintf('Manual_Exp%d_Pooled_%s',expNo,eff);
        makeBoxplotManual(d,s,genotypes,ttl,figDir,stem,true);
    end
end

disp("Done. Figures saved to: " + figDir);

%% -------- local functions --------
function makeBoxplotImage(d,s,genotypes,yLab,ttl,figDir,stem,isPooled)
    f = figure('Color','w','Units','centimeters','Position',[2 2 18 12]);
    ax = axes(f); hold(ax,'on');

    mockColor = [0.72 0.72 0.72];
    treatColor = [0.15 0.15 0.15];
    colors = [mockColor; treatColor];
    offsets = [-0.18 0.18];
    markers = {'o','^'};

    for g = 1:numel(genotypes)
        for c = 1:2
            cond = ["Mock","Treatment"];
            sub = d(d.genotype==genotypes(g) & d.condition==cond(c),:);
            if isempty(sub); continue; end
            x0 = g + offsets(c);
            vals = sub.image_value;

            boxchart(ax,repmat(x0,height(sub),1),vals, ...
                'BoxWidth',0.28,'BoxFaceColor',colors(c,:), ...
                'MarkerStyle','none','LineWidth',1.1);

            if isPooled
                for repNo = 1:2
                    sr = sub(sub.repeat==repNo,:);
                    if isempty(sr); continue; end
                    jitter = deterministicJitter(height(sr),0.045);
                    scatter(ax,x0+jitter,sr.image_value,32, ...
                        'Marker',markers{repNo}, ...
                        'MarkerFaceColor',colors(c,:), ...
                        'MarkerEdgeColor',[0 0 0], ...
                        'LineWidth',0.6);
                end
            else
                jitter = deterministicJitter(height(sub),0.045);
                scatter(ax,x0+jitter,vals,32, ...
                    'Marker','o','MarkerFaceColor',colors(c,:), ...
                    'MarkerEdgeColor',[0 0 0],'LineWidth',0.6);
            end
        end
    end

    xlim(ax,[0.5 numel(genotypes)+0.5]);
    xticks(ax,1:numel(genotypes)); xticklabels(ax,genotypes);
    ylabel(ax,yLab);
    title(ax,ttl,'FontWeight','normal');
    ax.Box='off'; ax.TickDir='out'; ax.LineWidth=1;
    ax.FontName='Arial'; ax.FontSize=10;
    grid(ax,'off');

    yl = ylim(ax);
    span = yl(2)-yl(1);
    for g = 1:numel(genotypes)
        ss = s(s.genotype==genotypes(g),:);
        if isempty(ss); continue; end
        p = ss.p_holm(1);
        label = pLabel(p);
        text(ax,g,yl(2)-0.02*span,label,'HorizontalAlignment','center', ...
            'VerticalAlignment','top','FontSize',8);
    end
    ylim(ax,[yl(1),yl(2)+0.08*span]);

    h1 = scatter(ax,nan,nan,36,'s','filled','MarkerFaceColor',mockColor,'MarkerEdgeColor',[0 0 0]);
    h2 = scatter(ax,nan,nan,36,'s','filled','MarkerFaceColor',treatColor,'MarkerEdgeColor',[0 0 0]);
    if isPooled
        h3 = scatter(ax,nan,nan,32,'o','MarkerFaceColor',[1 1 1],'MarkerEdgeColor',[0 0 0]);
        h4 = scatter(ax,nan,nan,32,'^','MarkerFaceColor',[1 1 1],'MarkerEdgeColor',[0 0 0]);
        legend(ax,[h1 h2 h3 h4],{'Mock','Treatment','Repeat 1','Repeat 2'}, ...
            'Location','best','Box','off');
    else
        legend(ax,[h1 h2],{'Mock','Treatment'},'Location','best','Box','off');
    end

    exportgraphics(f,fullfile(figDir,[stem '.png']),'Resolution',300);
    exportgraphics(f,fullfile(figDir,[stem '.pdf']),'ContentType','vector');
    close(f);
end

function makeBoxplotManual(d,s,genotypes,ttl,figDir,stem,isPooled)
    f = figure('Color','w','Units','centimeters','Position',[2 2 18 12]);
    ax = axes(f); hold(ax,'on');

    mockColor = [0.72 0.72 0.72];
    treatColor = [0.15 0.15 0.15];
    colors = [mockColor; treatColor];
    offsets = [-0.18 0.18];
    markers = {'o','^'};

    for g = 1:numel(genotypes)
        for c = 1:2
            cond = ["Mock","Treatment"];
            sub = d(d.genotype==genotypes(g) & d.condition==cond(c),:);
            if isempty(sub); continue; end
            x0 = g + offsets(c);
            vals = sub.positive_percent;

            boxchart(ax,repmat(x0,height(sub),1),vals, ...
                'BoxWidth',0.28,'BoxFaceColor',colors(c,:), ...
                'MarkerStyle','none','LineWidth',1.1);

            if isPooled
                for repNo = 1:2
                    sr = sub(sub.repeat_num==repNo,:);
                    if isempty(sr); continue; end
                    jitter = deterministicJitter(height(sr),0.045);
                    scatter(ax,x0+jitter,sr.positive_percent,32, ...
                        'Marker',markers{repNo}, ...
                        'MarkerFaceColor',colors(c,:), ...
                        'MarkerEdgeColor',[0 0 0], ...
                        'LineWidth',0.6);
                end
            else
                jitter = deterministicJitter(height(sub),0.045);
                scatter(ax,x0+jitter,vals,32, ...
                    'Marker','o','MarkerFaceColor',colors(c,:), ...
                    'MarkerEdgeColor',[0 0 0],'LineWidth',0.6);
            end
        end
    end

    xlim(ax,[0.5 numel(genotypes)+0.5]);
    ylim(ax,[-5 112]);
    yticks(ax,0:20:100);
    xticks(ax,1:numel(genotypes)); xticklabels(ax,genotypes);
    ylabel(ax,'Cell-death-positive leaves per biological replicate (%)');
    title(ax,ttl,'FontWeight','normal');
    ax.Box='off'; ax.TickDir='out'; ax.LineWidth=1;
    ax.FontName='Arial'; ax.FontSize=10;
    grid(ax,'off');

    for g = 1:numel(genotypes)
        ss = s(s.genotype==genotypes(g),:);
        if isempty(ss); continue; end
        p = ss.p_holm(1);
        text(ax,g,106,pLabel(p),'HorizontalAlignment','center', ...
            'VerticalAlignment','top','FontSize',8);
    end

    h1 = scatter(ax,nan,nan,36,'s','filled','MarkerFaceColor',mockColor,'MarkerEdgeColor',[0 0 0]);
    h2 = scatter(ax,nan,nan,36,'s','filled','MarkerFaceColor',treatColor,'MarkerEdgeColor',[0 0 0]);
    if isPooled
        h3 = scatter(ax,nan,nan,32,'o','MarkerFaceColor',[1 1 1],'MarkerEdgeColor',[0 0 0]);
        h4 = scatter(ax,nan,nan,32,'^','MarkerFaceColor',[1 1 1],'MarkerEdgeColor',[0 0 0]);
        legend(ax,[h1 h2 h3 h4],{'Mock','Treatment','Repeat 1','Repeat 2'}, ...
            'Location','best','Box','off');
    else
        legend(ax,[h1 h2],{'Mock','Treatment'},'Location','best','Box','off');
    end

    exportgraphics(f,fullfile(figDir,[stem '.png']),'Resolution',300);
    exportgraphics(f,fullfile(figDir,[stem '.pdf']),'ContentType','vector');
    close(f);
end

function j = deterministicJitter(n,width)
    if n<=1
        j = zeros(n,1);
    else
        j = linspace(-width,width,n)';
    end
end

function txt = pLabel(p)
    if isnan(p)
        txt = "p = n/a";
    elseif p < 0.001
        txt = "Holm p < 0.001";
    elseif p < 0.05
        txt = sprintf('Holm p = %.3f *',p);
    else
        txt = sprintf('Holm p = %.3f',p);
    end
end
