Here I want to give a more Details on the Programms used in this Work

Following scripts provided here were used and adapted for this work, although I have already mentioned them in the work, I wanted to share the sources for the various packages from GitHub or the original website here.  AI-assisted coding tools
were used during code development, as described in the Thesis.


Python

NumPy:
https://github.com/numpy/numpy
https://numpy.org/doc/stable/

pandas:
https://github.com/pandas-dev/pandas
https://pandas.pydata.org/docs/

SciPy:
https://github.com/scipy/scipy
https://docs.scipy.org/doc/scipy/

OpenCV:
https://github.com/opencv/opencv
https://docs.opencv.org/

tifffile:
https://github.com/cgohlke/tifffile

Matplotlib:
https://github.com/matplotlib/matplotlib
https://matplotlib.org/stable/

MATLAB

MathWorks MATLAB documentation:
https://www.mathworks.com/help/matlab/

Functions used include:
nchoosek
median
prctile
readtable
boxchart