GEL PICTURES

Selected amplification figures prepared from Results.pdf and matched to successful amplification steps in the project workflow.
Each figure contains the polymerase and the full PCR program.
